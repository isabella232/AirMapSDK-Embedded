"""
  Airmap package init code
  AirMapSDK

  Created by AirMap Team on 6/28/16.
  Copyright (c) 2016 AirMap, Inc. All rights reserved.
"""

import connect
import statusAPI
import flightAPI
import drone
import log
import telemetryAPI
import alertsAPI
